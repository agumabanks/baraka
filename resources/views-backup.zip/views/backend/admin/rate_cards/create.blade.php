@extends('backend.partials.master')
@section('maincontent')
<div class="container">
  <h3>Create Rate Card</h3>
  <p class="text-muted">Stub UI — pricing editor to be implemented.</p>
  <a class="btn btn-secondary" href="{{ route('admin.rate-cards.index') }}">Back</a>
</div>
@endsection

