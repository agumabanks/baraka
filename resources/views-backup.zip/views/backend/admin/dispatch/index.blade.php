@extends('backend.partials.master')
@section('maincontent')
<div class="container">
  <h3>Pickup Dispatch Board</h3>
  <p>Assign drivers to pickups and view ETAs (stub).</p>
</div>
@endsection

