@extends('backend.partials.master')
@section('maincontent')
<div class="container">
  <h3>Create Shipment</h3>
  <p class="text-muted">This form is a minimal stub. Booking Wizard handles full creation.</p>
  <a class="btn btn-secondary" href="{{ route('admin.shipments.index') }}">Back</a>
</div>
@endsection

