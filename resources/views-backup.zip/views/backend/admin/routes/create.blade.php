@extends('backend.partials.master')
@section('maincontent')
<div class="container">
  <h3>Create Route</h3>
  <p class="text-muted">Stub screen. Use routing module to manage stops.</p>
  <a class="btn btn-secondary" href="{{ route('admin.routes.index') }}">Back</a>
</div>
@endsection

