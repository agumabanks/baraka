@extends('backend.partials.master')
@section('maincontent')
<div class="container">
  <h3>Create Commodity</h3>
  <p class="text-muted">Stub form.</p>
  <a class="btn btn-secondary" href="{{ route('admin.commodities.index') }}">Back</a>
</div>
@endsection

