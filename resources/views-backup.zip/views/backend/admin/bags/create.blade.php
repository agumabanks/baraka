@extends('backend.partials.master')
@section('maincontent')
<div class="container">
  <h3>Create Bag</h3>
  <p class="text-muted">Stub only. Use consolidation screens to build real bags.</p>
  <a class="btn btn-secondary" href="{{ route('admin.bags.index') }}">Back</a>
</div>
@endsection

