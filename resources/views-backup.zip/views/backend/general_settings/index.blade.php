@extends('backend.partials.master')
@section('title')
    {{ __('menus.general_settings') }}
@endsection
@section('maincontent')
<div class="container-fluid  dashboard-content">
    <!-- pageheader -->
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <div class="page-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{route('dashboard.index')}}" class="breadcrumb-link">{{ __('dashboard.title') }}</a></li>
                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link active">{{ __('menus.settings') }}</a></li>
                            <li class="breadcrumb-item"><a href="{{route('general-settings.index')}}" class="breadcrumb-link active">{{__('menus.general_settings')}}</a></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- end pageheader -->
    <div class="row">
        <!-- basic form -->
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <p class="h3">{{__('menus.general_settings')}}</h2>
                    <form action="{{route('general-settings.update')}}"  method="POST" enctype="multipart/form-data" id="basicform">
                        @method('PUT')
                        @csrf
                        <div class="row">
                            <div class="col-12 col-md-6">
                                <div class="form-group">
                                    <label for="name">{{ __('levels.application_name') }}</label>
                                    <input id="name" type="text" name="name" data-parsley-trigger="change" placeholder="{{ __('placeholder.Enter_name') }}" autocomplete="off" class="form-control @error('name') is-invalid @enderror" value="{{ $settings->name }}" require>
                                    @error('name')
                                        <small class="text-danger mt-2">{{ $message }}</small>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="phone">{{ __('levels.phone') }}</label>
                                    <input id="phone" type="text" name="phone" data-parsley-trigger="change" placeholder="{{ __('placeholder.Enter_phone') }}" autocomplete="off" class="form-control @error('phone') is-invalid @enderror" value="{{ $settings->phone }}" require>
                                    @error('phone')
                                        <small class="text-danger mt-2">{{ $message }}</small>
                                    @enderror
                                </div>
                                <div class="form-group pt-3">
                                    <label for="email">{{ __('levels.email') }}</label>
                                    <input id="email" type="text" name="email" data-parsley-trigger="change" placeholder="{{ __('placeholder.enter_email') }}" autocomplete="off" class="form-control @error('email') is-invalid @enderror" value="{{ $settings->email }}" require>
                                    @error('email')
                                        <small class="text-danger mt-2">{{ $message }}</small>
                                    @enderror
                                </div>
                                <div class="form-group pt-3">
                                    <label for="address">{{ __('levels.address') }}</label>
                                    <textarea id="address" type="text" name="address" data-parsley-trigger="change" placeholder="{{ __('placeholder.enter_address') }}" autocomplete="off" class="form-control @error('address') is-invalid @enderror" require>{{ $settings->address }}</textarea>
                                    @error('address')
                                        <small class="text-danger mt-2">{{ $message }}</small>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="currency">{{ __('levels.currency') }}</label>
                                    <select class="form-control @error('currency') is-invalid @enderror" id="currency" name="currency"  required>
                                        <option value="" selected disabled>Select Currency</option>
                                        @forelse ($currencies as $currency)
                                            <option value="{{ $currency->symbol }}" {{$settings->currency == $currency->symbol ? 'selected' : ''}}>{{ @$currency->name }} {{ @$currency->symbol }}</option>
                                        @empty
                                            <option value="&#36;" {{$settings->currency == '$' ? 'selected' : ''}}>Dollar &#36;</option>
                                        @endforelse
                                    </select>
                                    @error('currency')
                                        <small class="text-danger mt-2">{{ $message }}</small>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="currency">{{ __('levels.currency_position') }}</label>
                                    <select class="form-control @error('currency') is-invalid @enderror" id="currency_position" name="currency_position"  required>
                                        <option value="" selected disabled>Select Currency Position</option>
                                        <option value="left" {{$settings->currency_position == 'left' ? 'selected' : ''}}>{{__('levels.left')}} ( {{settings()->currency}} 100 )</option>
                                        <option value="right" {{$settings->currency_position == 'right' ? 'selected' : ''}}>{{__('levels.right')}} ( 100 {{settings()->currency}} )</option>
                                        <option value="left_space" {{$settings->currency_position == 'left_space' ? 'selected' : ''}}>{{__('levels.left_space')}} ( {{settings()->currency}} 100 )</option>
                                        <option value="right_space" {{$settings->currency_position == 'right_space' ? 'selected' : ''}}>{{__('levels.right_space')}} ( 100 {{settings()->currency}} )</option>
                                    </select>
                                    @error('currency_position')
                                        <small class="text-danger mt-2">{{ $message }}</small>
                                    @enderror
                                </div>
                                <div class="form-group pt-3">
                                    <label for="journey_day">{{ __('levels.journey_day') }}</label>
                                    <input id="journey_day" type="number" min="1" name="journey_day" data-parsley-trigger="change" placeholder="{{ __('levels.journey_day') }}" autocomplete="off" class="form-control @error('journey_day') is-invalid @enderror" value="{{ $settings->journey_day }}" require>
                                    @error('journey_day')
                                        <small class="text-danger mt-2">{{ $message }}</small>
                                    @enderror
                                </div>
                                <div class="form-group pt-3">
                                    <label for="delivery_charge_head_id">{{ __('levels.delivery_charge_head') }}</label>
                                    <select name="delivery_charge_head_id" id="delivery_charge_head_id" class="form-control select2">
                                        <option value="">{{ __('menus.select') }}</option>
                                        @foreach ($expenseHeads as $expenseHead)
                                            <option value="{{ $expenseHead->id }}" {{ settings()->delivery_charge_head_id == $expenseHead->id ? 'selected' : '' }}>{{ $expenseHead->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group pt-3">
                                    <label for="packaging_charge_head_id">{{ __('levels.packaging_charge_head') }}</label>
                                    <select name="packaging_charge_head_id" id="packaging_charge_head_id" class="form-control select2">
                                        <option value="">{{ __('menus.select') }}</option>
                                        @foreach ($expenseHeads as $expenseHead)
                                            <option value="{{ $expenseHead->id }}" {{ settings()->packaging_charge_head_id == $expenseHead->id ? 'selected' : '' }}>{{ $expenseHead->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group pt-3">
                                    <label for="parcel_vat">{{ __('levels.parcel_vat') }}</label>
                                    <input id="parcel_vat" type="number" min="0" name="parcel_vat" data-parsley-trigger="change" placeholder="{{ __('levels.parcel_vat') }}" autocomplete="off" class="form-control @error('parcel_vat') is-invalid @enderror" value="{{ old('parcel_vat',settings()->parcel_vat) }}">
                                    @error('parcel_vat')
                                        <small class="text-danger mt-2">{{ $message }}</small>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="primary_color">{{ __('levels.primary_color') }}</label>
                                            <input id="primary_color" type="color" name="primary_color"  placeholder="Enter favicon" autocomplete="off" class="form-control @error('primary_color') is-invalid @enderror" value="{{ old('primary_color',settings()->primary_color) }}" require>
                                            @error('favicon')
                                                <small class="text-danger mt-2">{{ $message }}</small>
                                            @enderror
                                        </div>
                                    </div> 
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="text_color">{{ __('levels.text_color') }}</label>
                                            <input id="text_color" type="color" name="text_color"  placeholder="Enter favicon" autocomplete="off" class="form-control @error('text_color') is-invalid @enderror" value="{{ old('text_color',settings()->text_color) }}" require>
                                            @error('text_color')
                                                <small class="text-danger mt-2">{{ $message }}</small>
                                            @enderror
                                        </div>
                                    </div> 
                                </div>
                                <div class="form-group">
                                    <label for="logo">{{ __('levels.logo') }}</label>
                                    <input id="logo" type="file" name="logo" data-parsley-trigger="change" placeholder="Enter logo" autocomplete="off" class="form-control @error('logo') is-invalid @enderror" value="{{ old('logo') }}" require>
                                    @error('logo')
                                        <small class="text-danger mt-2">{{ $message }}</small>
                                    @enderror
                                    <img src="{{$settings->logo_image}}" alt="user" class="rounded mt-3" width="150">
                                </div>
                                <div class="form-group">
                                    <label for="dark_logo">{{ __('levels.dark_logo') }}</label>
                                    <input id="dark_logo" type="file" name="dark_logo" data-parsley-trigger="change" placeholder="Enter logo" autocomplete="off" class="form-control @error('dark_logo') is-invalid @enderror" value="{{ old('dark_logo') }}">
                                    @error('dark_logo')
                                        <small class="text-danger mt-2">{{ $message }}</small>
                                    @enderror
                                    @if ($settings->dark_logo_image)
                                        <img src="{{$settings->dark_logo_image}}" alt="dark logo" class="rounded mt-3" width="150">
                                    @endif
                                </div>
                                <div class="form-group pt-3">
                                    <div class="row">
                                        <div class="col-9">
                                            <label for="favicon">{{ __('levels.favicon') }}</label>
                                            <input id="favicon" type="file" name="favicon" data-parsley-trigger="change" placeholder="Enter favicon" autocomplete="off" class="form-control @error('favicon') is-invalid @enderror" value="{{ old('favicon') }}" require>
                                            @error('favicon')
                                                <small class="text-danger mt-2">{{ $message }}</small>
                                            @enderror
                                        </div>
                                        <div class="col-3  ">
                                            <img src="{{$settings->favicon_image}}" alt="user" class="rounded mt-3" width="60"  style="object-fit: contain">
                                        </div>
                                    </div>
                                </div>
                               
                          
                            </div>
                            <div class="col-md-12">
                                <div class="m-b-20">
                                    <span><strong>Cron jobs Setup:</strong> * * * * * cd /path-to-your-project && php artisan schedule:run >> /dev/null 2>&1 <a href="https://laravel.com/docs/10.x/scheduling" target="_blank" class="text-primary"><strong>Read More</strong></a></span>
                                </div>
                            </div>
                            
                            @if(hasPermission('general_settings_update'))
                            <div class="row pt-4">
                                <div class="col-12 text-right">
                                    <button type="submit" class="btn btn-space btn-primary">{{ __('levels.save_change') }}</button>
                                </div>
                            </div>
                            @endif
                        </div>

                    </form>
                </div>
            </div>
        </div>
        <!-- end basic form -->
    </div>
</div>
<!-- end wrapper  -->
@endsection()
