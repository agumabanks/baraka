
        <!-- footer -->
        <div class="footer fixed-bottom">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-12 col-12 footer-text">
                           {{settings()->copyright}}
                    </div>

                </div>
            </div>
        </div>
        <!-- end footer -->
    </div>
</main>
