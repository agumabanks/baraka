@extends('backend.partials.master')
@section('title')
    Edit Translation
@endsection
@section('maincontent')
<div class="container-fluid dashboard-content">
    <!-- pageheader -->
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <div class="page-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{route('dashboard.index')}}" class="breadcrumb-link">{{ __('dashboard.title') }}</a></li>
                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link active">{{ __('menus.settings') }}</a></li>
                            <li class="breadcrumb-item"><a href="{{route('general-settings.index')}}" class="breadcrumb-link active">{{__('settings.title')}}</a></li>
                            <li class="breadcrumb-item"><a href="{{route('translations.index')}}" class="breadcrumb-link active">{{__('settings.manage_translations')}}</a></li>
                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link active">Edit Translation</a></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- end pageheader -->
    <div class="row">
        <!-- basic form -->
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="{{route('translations.update', $translation->id)}}" method="POST" enctype="multipart/form-data" id="translationForm">
                        @csrf
                        @method('PUT')
                        <div class="row">
                            <div class="col-12">
                                <h3>Edit Translation</h3>
                                <p class="text-muted">
                                    <strong>Current Key:</strong> {{ $translation->key }} | 
                                    <strong>Language:</strong> {{ strtoupper($translation->language_code) }}
                                </p>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="key">
                                        {{ __('settings.translation_key') }} 
                                        <span class="text-danger">*</span>
                                    </label>
                                    <input id="key" type="text" name="key" class="form-control @error('key') is-invalid @enderror" 
                                           placeholder="e.g., common.save" required="required"
                                           value="{{ old('key', $translation->key) }}"
                                           list="key-suggestions">
                                    <datalist id="key-suggestions">
                                        @foreach($keys as $existingKey)
                                            <option value="{{ $existingKey }}">
                                        @endforeach
                                    </datalist>
                                    @error('key')
                                        <small class="text-danger mt-2">{{ $message }}</small>
                                    @enderror
                                    <small class="form-text text-muted">
                                        Use dot notation: file.key (e.g., dashboard.title)
                                    </small>
                                </div>

                                <div class="form-group">
                                    <label for="language_code">
                                        {{ __('settings.language_code') }} 
                                        <span class="text-danger">*</span>
                                    </label>
                                    <select id="language_code" name="language_code" class="form-control @error('language_code') is-invalid @enderror" required="required">
                                        <option value="">{{ __('common.select') }} {{ __('settings.language_code') }}</option>
                                        @foreach($languages as $lang)
                                            <option value="{{ $lang }}" {{ old('language_code', $translation->language_code) == $lang ? 'selected' : '' }}>
                                                {{ strtoupper($lang) }} - {{ __('settings.' . $lang) }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('language_code')
                                        <small class="text-danger mt-2">{{ $message }}</small>
                                    @enderror
                                </div>

                                <div class="form-group">
                                    <label for="value">
                                        {{ __('settings.translation_value') }} 
                                        <span class="text-danger">*</span>
                                    </label>
                                    <textarea id="value" name="value" class="form-control @error('value') is-invalid @enderror" 
                                              rows="3" required="required"
                                              placeholder="Enter translation text...">{{ old('value', $translation->value) }}</textarea>
                                    @error('value')
                                        <small class="text-danger mt-2">{{ $message }}</small>
                                    @enderror
                                    <div class="mt-2">
                                        <p class="text-muted small">Preview: <span class="badge bg-light text-dark" id="valuePreview">{{ $translation->value }}</span></p>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="description">{{ __('settings.description') }}</label>
                                    <textarea id="description" name="description" class="form-control @error('description') is-invalid @enderror" 
                                              rows="2" placeholder="Optional description of this translation...">{{ old('description', $translation->description) }}</textarea>
                                    @error('description')
                                        <small class="text-danger mt-2">{{ $message }}</small>
                                    @enderror
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-header">
                                        <h5><i class="fas fa-language"></i> Translation Progress</h5>
                                    </div>
                                    <div class="card-body">
                                        <div id="languageProgress">
                                            @foreach($languages as $lang)
                                                @if($lang == $translation->language_code)
                                                    <div class="mb-2">
                                                        <div class="d-flex justify-content-between align-items-center">
                                                            <span>{{ strtoupper($lang) }}</span>
                                                            <span class="badge bg-success">Current</span>
                                                        </div>
                                                        <div class="progress mt-1">
                                                            <div class="progress-bar bg-success" style="width: 100%">
                                                                {{ $translation->value }}
                                                            </div>
                                                        </div>
                                                    </div>
                                                @else
                                                    <div class="mb-2">
                                                        <div class="d-flex justify-content-between align-items-center">
                                                            <span>{{ strtoupper($lang) }}</span>
                                                            <span class="badge bg-secondary">Other</span>
                                                        </div>
                                                        <div class="progress mt-1">
                                                            <div class="progress-bar bg-secondary" style="width: 50%">
                                                                Need translation
                                                            </div>
                                                        </div>
                                                    </div>
                                                @endif
                                            @endforeach
                                        </div>
                                        
                                        <hr>
                                        <div class="text-center">
                                            <p class="mb-2">Quick copy to other languages:</p>
                                            <div class="btn-group">
                                                @foreach($languages as $lang)
                                                    @if($lang != $translation->language_code)
                                                        <button type="button" class="btn btn-sm btn-outline-primary copy-to-lang" data-lang="{{ $lang }}">
                                                            {{ strtoupper($lang) }}
                                                        </button>
                                                    @endif
                                                @endforeach
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="card mt-3">
                                    <div class="card-header">
                                        <h5><i class="fas fa-chart-bar"></i> Translation Statistics</h5>
                                    </div>
                                    <div class="card-body">
                                        <dl class="row">
                                            <dt class="col-sm-6">Created:</dt>
                                            <dd class="col-sm-6">{{ $translation->created_at->format('M d, Y H:i') }}</dd>
                                            
                                            <dt class="col-sm-6">Updated:</dt>
                                            <dd class="col-sm-6">{{ $translation->updated_at->format('M d, Y H:i') }}</dd>
                                            
                                            <dt class="col-sm-6">Value Length:</dt>
                                            <dd class="col-sm-6">{{ strlen($translation->value) }} characters</dd>
                                        </dl>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 mt-4">
                                <div class="d-flex justify-content-between">
                                    <a href="{{ route('translations.index') }}" class="btn btn-secondary">
                                        <i class="fas fa-arrow-left"></i> {{ __('common.back') }}
                                    </a>
                                    <div>
                                        <button type="button" class="btn btn-danger mr-2" 
                                                onclick="confirmDelete()">
                                            <i class="fas fa-trash"></i> {{ __('common.delete') }}
                                        </button>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-save"></i> {{ __('settings.save_changes') }}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- end basic form -->
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Delete</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this translation?</p>
                <p class="text-muted">
                    <strong>Key:</strong> {{ $translation->key }}<br>
                    <strong>Language:</strong> {{ $translation->language_code }}<br>
                    <strong>Value:</strong> {{ Str::limit($translation->value, 100) }}
                </p>
                <p class="text-warning">This action cannot be undone!</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <form action="{{ route('translations.destroy', $translation->id) }}" method="POST" style="display: inline;">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    $(document).ready(function() {
        // Live preview of translation value
        $('#value').on('input', function() {
            var value = $(this).val();
            $('#valuePreview').text(value || '(empty)');
        });

        // Copy value to other languages
        $('.copy-to-lang').click(function() {
            var targetLang = $(this).data('lang');
            var currentValue = $('#value').val();
            var currentKey = $('#key').val();
            
            if (confirm('Copy this translation to ' + targetLang.toUpperCase() + '?\n\nThis will create a new translation for that language.')) {
                $.post('{{ route("translations.store") }}', {
                    _token: '{{ csrf_token() }}',
                    key: currentKey,
                    language_code: targetLang,
                    value: currentValue,
                    description: 'Copied from {{ $translation->language_code }} translation'
                }, function(response) {
                    location.reload();
                });
            }
        });

        // Validate key format (contains dot)
        $('#translationForm').submit(function(e) {
            var key = $('#key').val();
            if (key && !key.includes('.')) {
                alert('Translation key should include a dot (.) in format: file.key');
                e.preventDefault();
                $('#key').focus();
                return false;
            }
        });
    });

    function confirmDelete() {
        $('#deleteModal').modal('show');
    }
</script>
@endpush
