@extends('backend.partials.master')
@section('title')
    {{ __('settings.manage_translations') }}
@endsection
@section('maincontent')
<div class="container-fluid dashboard-content">
    <!-- pageheader -->
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <div class="page-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{route('dashboard.index')}}" class="breadcrumb-link">{{ __('dashboard.title') }}</a></li>
                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link active">{{ __('menus.settings') }}</a></li>
                            <li class="breadcrumb-item"><a href="{{route('general-settings.index')}}" class="breadcrumb-link active">{{__('settings.title')}}</a></li>
                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link active">{{__('settings.manage_translations')}}</a></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- end pageheader -->
    <div class="row">
        <!-- filters -->
        <div class="col-12">
            <div class="card mb-3">
                <div class="card-body">
                    <form action="{{ route('translations.index') }}" method="GET" class="row align-items-end">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="language_code">{{ __('settings.language_code') }}</label>
                                <select name="language_code" id="language_code" class="form-control">
                                    <option value="all" {{ $languageCode == 'all' ? 'selected' : '' }}>All Languages</option>
                                    @foreach($languages as $lang)
                                        <option value="{{ $lang }}" {{ $languageCode == $lang ? 'selected' : '' }}>
                                            {{ strtoupper($lang) }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="key">{{ __('settings.translation_key') }}</label>
                                <input type="text" name="key" id="key" class="form-control" 
                                       placeholder="Search by key..." value="{{ $key }}">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <button type="submit" class="btn btn-primary w-100">{{ __('common.filter') }}</button>
                            </div>
                        </div>
                        <div class="col-md-3 text-right">
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <div class="btn-group w-100">
                                    @if(hasPermission('translation_create'))
                                        <a href="{{ route('translations.create') }}" class="btn btn-success">
                                            <i class="fas fa-plus"></i> {{ __('settings.add_translation') }}
                                        </a>
                                    @endif
                                    <button type="button" class="btn btn-info dropdown-toggle dropdown-toggle-split" 
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fas fa-download"></i> {{ __('common.export') }}
                                    </button>
                                    <div class="dropdown-menu">
                                        @foreach($languages as $lang)
                                            <a class="dropdown-item" href="{{ route('translations.export', ['language_code' => $lang]) }}">
                                                Export {{ strtoupper($lang) }}
                                            </a>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- translations table -->
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th width="20%">{{ __('settings.translation_key') }}</th>
                                    <th width="10%">{{ __('settings.language_code') }}</th>
                                    <th width="40%">{{ __('settings.translation_value') }}</th>
                                    <th width="20%">{{ __('settings.description') }}</th>
                                    <th width="10%" class="text-center">{{ __('common.actions') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($translations as $translation)
                                    <tr>
                                        <td>
                                            <code class="text-primary">{{ $translation->key }}</code>
                                        </td>
                                        <td>
                                            <span class="badge badge-info">{{ strtoupper($translation->language_code) }}</span>
                                        </td>
                                        <td>
                                            <div class="translation-value">
                                                <span class="d-block">{{ Str::limit($translation->value, 50) }}</span>
                                                @if(strlen($translation->value) > 50)
                                                    <small class="text-muted">
                                                        <a href="#" class="text-muted" data-toggle="tooltip" 
                                                           title="{{ $translation->value }}">
                                                            {{ __('common.view_details') }}
                                                        </a>
                                                    </small>
                                                @endif
                                            </div>
                                        </td>
                                        <td>
                                            <small class="text-muted">{{ $translation->description }}</small>
                                        </td>
                                        <td class="text-center">
                                            <div class="btn-group btn-group-sm">
                                                @if(hasPermission('translation_edit'))
                                                    <a href="{{ route('translations.edit', $translation->id) }}" 
                                                       class="btn btn-sm btn-primary" title="Edit">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                @endif
                                                @if(hasPermission('translation_delete'))
                                                    <form action="{{ route('translations.destroy', $translation->id) }}" 
                                                          method="POST" style="display: inline-block;" 
                                                          onsubmit="return confirm('Are you sure you want to delete this translation?')">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                @endif
                                            </div>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5" class="text-center py-4">
                                            {{ __('common.no_data') }}
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                    
                    @if($translations->hasPages())
                        <div class="d-flex justify-content-center mt-4">
                            {{ $translations->links() }}
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('styles')
<style>
    .translation-value {
        max-width: 300px;
        word-wrap: break-word;
    }
</style>
@endpush

@push('scripts')
<script>
    $(document).ready(function() {
        $('[data-toggle="tooltip"]').tooltip();
    });
</script>
@endpush
