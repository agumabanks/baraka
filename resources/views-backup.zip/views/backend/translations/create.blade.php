@extends('backend.partials.master')
@section('title')
    {{ __('settings.add_translation') }}
@endsection
@section('maincontent')
<div class="container-fluid dashboard-content">
    <!-- pageheader -->
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="page-header">
                <div class="page-breadcrumb">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{route('dashboard.index')}}" class="breadcrumb-link">{{ __('dashboard.title') }}</a></li>
                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link active">{{ __('menus.settings') }}</a></li>
                            <li class="breadcrumb-item"><a href="{{route('general-settings.index')}}" class="breadcrumb-link active">{{__('settings.title')}}</a></li>
                            <li class="breadcrumb-item"><a href="{{route('translations.index')}}" class="breadcrumb-link active">{{__('settings.manage_translations')}}</a></li>
                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link active">{{__('settings.add_translation')}}</a></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- end pageheader -->
    <div class="row">
        <!-- basic form -->
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="{{route('translations.store')}}" method="POST" enctype="multipart/form-data" id="translationForm">
                        @csrf
                        <div class="row">
                            <div class="col-12">
                                <h3>{{ __('settings.add_translation') }}</h3>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="key">
                                        {{ __('settings.translation_key') }} 
                                        <span class="text-danger">*</span>
                                    </label>
                                    <input id="key" type="text" name="key" class="form-control @error('key') is-invalid @enderror" 
                                           placeholder="e.g., common.save" required="required"
                                           value="{{ old('key') }}"
                                           list="key-suggestions">
                                    <datalist id="key-suggestions">
                                        @foreach($keys as $existingKey)
                                            <option value="{{ $existingKey }}">
                                        @endforeach
                                    </datalist>
                                    @error('key')
                                        <small class="text-danger mt-2">{{ $message }}</small>
                                    @enderror
                                    <small class="form-text text-muted">
                                        Use dot notation: file.key (e.g., dashboard.title)
                                    </small>
                                </div>

                                <div class="form-group">
                                    <label for="language_code">
                                        {{ __('settings.language_code') }} 
                                        <span class="text-danger">*</span>
                                    </label>
                                    <select id="language_code" name="language_code" class="form-control @error('language_code') is-invalid @enderror" required="required">
                                        <option value="">{{ __('common.select') }} {{ __('settings.language_code') }}</option>
                                        @foreach($languages as $lang)
                                            <option value="{{ $lang }}" {{ old('language_code') == $lang ? 'selected' : '' }}>
                                                {{ strtoupper($lang) }} - {{ __('settings.' . $lang) }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('language_code')
                                        <small class="text-danger mt-2">{{ $message }}</small>
                                    @enderror
                                </div>

                                <div class="form-group">
                                    <label for="value">
                                        {{ __('settings.translation_value') }} 
                                        <span class="text-danger">*</span>
                                    </label>
                                    <textarea id="value" name="value" class="form-control @error('value') is-invalid @enderror" 
                                              rows="3" required="required"
                                              placeholder="Enter translation text...">{{ old('value') }}</textarea>
                                    @error('value')
                                        <small class="text-danger mt-2">{{ $message }}</small>
                                    @enderror
                                </div>

                                <div class="form-group">
                                    <label for="description">{{ __('settings.description') }}</label>
                                    <textarea id="description" name="description" class="form-control @error('description') is-invalid @enderror" 
                                              rows="2" placeholder="Optional description of this translation...">{{ old('description') }}</textarea>
                                    @error('description')
                                        <small class="text-danger mt-2">{{ $message }}</small>
                                    @enderror
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-header">
                                        <h5><i class="fas fa-info-circle"></i> Translation Guidelines</h5>
                                    </div>
                                    <div class="card-body">
                                        <ul class="list-unstyled">
                                            <li class="mb-2">
                                                <i class="fas fa-check text-success"></i>
                                                Use descriptive keys with dot notation (file.key)
                                            </li>
                                            <li class="mb-2">
                                                <i class="fas fa-check text-success"></i>
                                                Keep keys consistent across all languages
                                            </li>
                                            <li class="mb-2">
                                                <i class="fas fa-check text-success"></i>
                                                Avoid HTML in simple text translations
                                            </li>
                                            <li class="mb-2">
                                                <i class="fas fa-check text-success"></i>
                                                Use placeholders like :name for dynamic values
                                            </li>
                                            <li class="mb-2">
                                                <i class="fas fa-check text-success"></i>
                                                Test translations in all supported languages
                                            </li>
                                        </ul>

                                        <h6>Common Key Patterns:</h6>
                                        <ul class="list-unstyled small">
                                            <li>• common.button_name - for buttons</li>
                                            <li>• page.section.title - for page titles</li>
                                            <li>• messages.success.key - for messages</li>
                                            <li>• validationrules.rule - for validation</li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="card mt-3">
                                    <div class="card-header">
                                        <h5><i class="fas fa-code"></i> Quick Examples</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="row text-sm">
                                            <div class="col-6">
                                                <strong>Key:</strong> dashboard.title<br>
                                                <strong>EN:</strong> Dashboard<br>
                                                <strong>FR:</strong> Tableau de bord<br>
                                                <strong>SW:</strong> Bodi ya dashibodi
                                            </div>
                                            <div class="col-6">
                                                <strong>Key:</strong> auth.signin_msg<br>
                                                <strong>EN:</strong> Signin successfully!<br>
                                                <strong>FR:</strong> Connexion réussie!<br>
                                                <strong>SW:</strong> Umeingia kwa mafanikio!
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 mt-4">
                                <div class="d-flex justify-content-between">
                                    <a href="{{ route('translations.index') }}" class="btn btn-secondary">
                                        <i class="fas fa-arrow-left"></i> {{ __('common.back') }}
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save"></i> {{ __('settings.save_changes') }}
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- end basic form -->
    </div>
</div>
@endsection

@push('scripts')
<script>
    $(document).ready(function() {
        // Auto-fill language display name when language code is selected
        $('#language_code').change(function() {
            var selectedLang = $(this).val();
            if (selectedLang) {
                var displayName = selectedLang.toUpperCase();
                $('#key').focus();
            }
        });

        // Validate key format (contains dot)
        $('#translationForm').submit(function(e) {
            var key = $('#key').val();
            if (key && !key.includes('.')) {
                alert('Translation key should include a dot (.) in format: file.key');
                e.preventDefault();
                $('#key').focus();
                return false;
            }
        });
    });
</script>
@endpush
