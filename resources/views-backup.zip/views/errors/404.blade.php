
@extends('errors.layout')
@section('title', __('Page Not Found'))
@section('code', '404')
@section('message-headline', __('Opps! Something went wrong.'))
@section('message-title', __('Page Not Found'))
@section('message', __('The page you are looking for has not been found on our server.'))
